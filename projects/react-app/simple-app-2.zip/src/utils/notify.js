import { toast } from "react-toastify";

export function notify() {
  toast("Successfully Deleted!");
}
